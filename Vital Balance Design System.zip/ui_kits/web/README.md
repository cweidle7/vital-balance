# Vital Balance · Web UI Kit

A catalog of every reusable component used across the Vital Balance pages. Open `index.html` for a live demo.

## Components

- **Navigation** (`.nav`) — fixed, glassy on cream pages, solid on scroll
- **Buttons** (`.btn`) — `--primary`, `--ghost`, `--outline-sage`, `--sm`, `--lg`, `--block`
- **Pills** (`.pill`) — filter chips with optional count
- **Variant pills** (`.variant-pill`) — selected state via `aria-pressed`
- **Product card** (`.product-card`) — full-bleed media + body with category, name, hook, price
- **Trust bar** (`.trustbar`) — animated marquee of certifications
- **Footer** (`.footer`) — brand mark, columns, newsletter, legal

## Token usage

All components rely on `colors_and_type.css`. Override at `:root` to retheme.

## Drop-in pattern

Include in this order in any HTML:
```html
<link rel="stylesheet" href="colors_and_type.css">
<link rel="stylesheet" href="components.css">
<script src="shared.js" defer></script>
```
